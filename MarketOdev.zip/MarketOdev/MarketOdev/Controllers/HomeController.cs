﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MarketOdev.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "ŞEN TİCARETİ FİRMASI SAHİBİ ERKAY ŞEN'İN HAYATI";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "ŞEN TİCARET İLETİŞİM SAYFASI";

            return View();
        }

    }
}